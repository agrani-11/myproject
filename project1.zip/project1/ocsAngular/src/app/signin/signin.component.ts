import { Component, OnInit } from '@angular/core';
import { EmitterserviceService } from '../emitterservice.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { toUnicode } from 'punycode';
import { DataService } from '../data.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
//   email = '';
//   password = '';
//   role='';
//   message;
//   myloginform;
//   constructor(
//     private Eservice:EmitterserviceService,
//     private service: AuthService,
//     private router: Router
//   ) { }

//   ngOnInit() {
//   }

//   onLogin() {
  
//   //   if (this.email.length == 0) {
//   //     alert('enter email');
//   //   } else if (this.password.length ==0) {
//   //     alert('enter password');
//   //   } else {

//   //     if(this.email=='ADMIN' && this.role=='ADMIN')
//   //     {
//   //         sessionStorage['login_status'] = '1';
//   //         localStorage.setItem('email',this.email);
//   //         localStorage.setItem('flag','true');
//   //         this.router.navigate(['/afterlogin']);
//   //     }
//   //     else if(this.role=='RECEPTIONIST' && this.email=='RECEPTIONIST')
//   //     {
        
//   //         sessionStorage['login_status'] = '1';
//   //         localStorage.setItem('email',this.email);
//   //         localStorage.setItem('flag','true');
//   //        // this.emtService.navBarSwitch(true);
//   //         this.router.navigate(['/afterlogin']);
//   //     }else if(this.role=='DOCTOR' && this.email=='DOCTOR')
//   //     {
//   //         sessionStorage['login_status'] = '1';
//   //         localStorage.setItem('email',this.email);
//   //         localStorage.setItem('flag','true');
//   //        // this.emtService.navBarSwitch(true);
//   //         this.router.navigate(['/afterlogin']);
//   //     }
//   //     else if(this.role=='PATIENT' && this.email=='PATIENT')
//   //     {
//   //         sessionStorage['login_status'] = '1';
//   //         localStorage.setItem('email',this.email);
//   //         localStorage.setItem('flag','true');
//   //        // this.emtService.navBarSwitch(true);
//   //         this.router.navigate(['/afterlogin']);
//   //     }else{
//   //       alert("invalid login");
//   //       this.router.navigate(['']);
//   //     }
      
//   //   }
//   // }
//   // onSignup() {
//   //     this.router.navigate(['/signup']);
//   //    }
//   //   }
//    // console.log("in sign in")
//    // let logincredentials=this.myloginform.form.value;
//     //this.message=this.service.getMessage();

//     //console.log(logincredentials);

//     //let isuservalid=this.service.LogIn(logincredentials);
//     //console.log(isuservalid)
//     //if(isuservalid)
//     //{
//      // console.log("user is valid");
//       //this.router.navigate(['home']);
//     //}
//     //else{
//     //  this.message="username/password is invalid";
//      // console.log(this.message)
     

//     //}

//     let loginCredentials = this.myloginform.form.value;
//     console.log(loginCredentials);

//     let isUserValid= this.service.CheckCredentialsWithDB(loginCredentials);
//     if(isUserValid)
//     {
//       console.log("User Is Valid");
      
//       this.router.navigate(['/home']); 
//     }
//     else{
//       this.message = "User Name / Password is Invalid!";
//     }
//   }
  


//   onSignup() {
//     this.router.navigate(['/signup']);
//   }

// }
email = '';
password = '';
role='';
constructor(
  private emtService:EmitterserviceService,
  private authService: AuthService,
  private router: Router
) { }

ngOnInit() {
}

onLogin() {

  if (this.email.length == 0) {
    alert('enter email');
  } else if (this.password.length ==0) {
    alert('enter password');
  } else {

    if(this.email=='ADMIN' && this.role=='ADMIN')
    {
        sessionStorage['login_status'] = '1';
        localStorage.setItem('email',this.email);
        localStorage.setItem('flag','true');
        this.router.navigate(['/afterlogin']);
    }
    else if(this.role=='RECEPTIONIST' && this.email=='RECEPTIONIST')
    {
      
        sessionStorage['login_status'] = '1';
        localStorage.setItem('email',this.email);
        localStorage.setItem('flag','true');
       // this.emtService.navBarSwitch(true);
        this.router.navigate(['/afterlogin']);
    }else if(this.role=='DOCTOR' && this.email=='DOCTOR')
    {
        sessionStorage['login_status'] = '1';
        localStorage.setItem('email',this.email);
        localStorage.setItem('flag','true');
       // this.emtService.navBarSwitch(true);
        this.router.navigate(['/afterlogin']);
    }
    else if(this.role=='PATIENT' && this.email=='PATIENT')
    {
        sessionStorage['login_status'] = '1';
        localStorage.setItem('email',this.email);
        localStorage.setItem('flag','true');
       // this.emtService.navBarSwitch(true);
        this.router.navigate(['/afterlogin']);
    }else{
      alert("invalid login");
      this.router.navigate(['']);
    }
    
  }
}


onSignup() {
  this.router.navigate(['/signup']);
}


}
