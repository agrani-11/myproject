import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listofpatients',
  templateUrl: './listofpatients.component.html',
  styleUrls: ['./listofpatients.component.css']
})
export class ListofpatientsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
