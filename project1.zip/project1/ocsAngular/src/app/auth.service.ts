import { Injectable } from '@angular/core';
import { Router,RouterStateSnapshot,ActivatedRouteSnapshot,CanActivate } from '@angular/router';
import { HttpClient, HttpHeaders,HttpRequest} from '@angular/common/http';
import { DataService } from './data.service';


@Injectable({
  providedIn: 'root'
})
export class AuthService implements CanActivate {
 
// //   constructor(
// //     private router: Router,
// //     private http: HttpClient) {
// //       console.log("aaaaaaaaaaaa")
// //       //this.flag=true;
// //      }

// //   canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
// //     // check if user has logged in
// //     if (sessionStorage['login_status'] == '1') {
// //      console.log("ffff");
// //    //   this.flag=true;
// //       return true;
// //     }
    
// //     this.router.navigate(['/signin']);
// //     return false;
// //   }

// // }

// message:"helloooooooo";
//   user:any
//  constructor(private router:Router,private service:DataService) { }
 
//  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) 
//  {   
//  if(this.Isloggedin())
//     {
//       console.log("user has logged in");
//       return true;
//     }
//     else
//     {
//       console.log("user has not logged in");
//       this.router.navigate(['/signin']);
//       return false;
//     }
// }


// Isloggedin()
// {
   
//   if(window.sessionStorage.getItem("isActive")!=null 
//   && 
//  window.sessionStorage.getItem("isActive")=="1")
// {
// // some logic to check if person has logged in
// return true;
// }

// else{
//   return false;
// }
// }
// CheckCredentialsWithDB(credentials)
// {
//   //Call Some  Service using Post Method
//   //to check credentials with DB 
//   if(credentials.UserName == "abc" && credentials.Password == "abc@123")
//   {
//     window.sessionStorage.setItem("isActive", "1");
//     return true;
//   }
//   else
//   {
//     return false;
//   }
// }
// // else if(window.sessionStorage.getItem("isActive")!=null 
// // && 
// // window.sessionStorage.getItem("isActive")=="2")
// // {
// // // some logic to check if person has logged in
// // return true;
// // }
// // else if(window.sessionStorage.getItem("isActive")!=null 
// // && 
// // window.sessionStorage.getItem("isActive")=="3")
// // {
// // // some logic to check if person has logged in
// // return true;
// // }
// // else{
// // return false;
// // }
// // }

// // isadmin()
// // {
// //   if(window.sessionStorage.getItem("isActive")!=null 
// //   && 
// //  window.sessionStorage.getItem("isActive")=="1")
// // {
// // // some logic to check if person has logged in
// // return true;
// // }
// // else{
// // return false;
// // }


// // }


// // ispatient()
// // {
// //   if(window.sessionStorage.getItem("isActive")!=null 
// //   && 
// //  window.sessionStorage.getItem("isActive")=="2")
// // {
// // // some logic to check if person has logged in
// // return true;
// // }
// // else{
// // return false;
// // }

// // }

// // isreceptionist()
// // {
// //   if(window.sessionStorage.getItem("isActive")!=null 
// //   && 
// //  window.sessionStorage.getItem("isActive")=="3")
// // {
 
// // //some logic to check if person has logged in
// // return true;
// // }
// // else{
// // return false;
// // }

// // }


// // isdoctor()
// // {
// //   if(window.sessionStorage.getItem("isActive")!=null 
// //   && 
// //  window.sessionStorage.getItem("isActive")=="4")
// // {
// // // some logic to check if person has logged in
// // return true;
// // }
// // else{
// // return false;
// // }

// // }
// // // LogIn(logincredentials) {
// // //    if(logincredentials.Name=="admin" &&
// // //         logincredentials.Password=="admin")
// // //    {
// // //      window.sessionStorage.setItem("isActive","1");
// // //      return true;
// // //     }
   

// // //     if(logincredentials.Name=="emp" &&
// // //         logincredentials.Password=="emp@123")
// // //    {
// // //      window.sessionStorage.setItem("isActive","2");//owner
// // //      return true;
// // //     }
   


// // //     if(logincredentials.Name=="user" &&
// // //         logincredentials.Password=="user@123")
// // //    {
// // //      window.sessionStorage.setItem("isActive","3");//user
// // //      return true;
// // //     }
   
// // //     else{
// // //      return false;
// // //     }
// // // }
// // function ($scope)
// //     {
// //     $scope.id=[1];
// //     }
// // LogIn(logincredentials):boolean {
// //   console.log("in auth");
// //   let observable =this.service.selectForLogin(logincredentials)
// //    observable.subscribe((result)=>{
// //     console.log("hello");
// //     this.user=result;
// //     console.log(this.user);
// //     console.log(this.user.role);
// //     window.sessionStorage.setItem('users',this.user.email)

// //     if(this.user.role=="ADMIN")
// //   {
// //     console.log("equal");
// //     window.sessionStorage.setItem("isActive","1");
// //     this.router.navigate(["/afterlogin"]);
// //   }
// //   else if(this.user.role=="PATIENT"){

// //     window.sessionStorage.setItem("isActive","2");
// //     this.router.navigate(["/home"]);

// //   }
// //   else if(this.user.role=="RECEPTIONIST")
// //   {
// //     window.sessionStorage.setItem("isActive","3");
// //     this.router.navigate(["/afterlogin"]);

// //   }
// //   else if(this.user.role=="DOCTOR"){

// //     window.sessionStorage.setItem("isActive","4");
// //     this.router.navigate(["/home"]);

// //   }
// //   else
// //   {
// //     return false;

// //   }
  
 
// //   });
  
// //   return true;

// // }


// // getMessage()
// // {
// //   console.log(this.message);

// //   return this.message;
// // }






// Logout()
// {
//   window.sessionStorage.setItem("isActive","0");
// }

// }
constructor(
  private router: Router,
  private http: HttpClient) {
    console.log("aaaaaaaaaaaa")
    //this.flag=true;
   }

canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
  // check if user has logged in
  if (sessionStorage['login_status'] == '1') {
   console.log("ffff");
 //   this.flag=true;
    return true;
  }
  
  this.router.navigate(['/signin']);
  return false;
}

}