import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-listofdoctors',
  templateUrl: './listofdoctors.component.html',
  styleUrls: ['./listofdoctors.component.css']
})
export class ListofdoctorsComponent implements OnInit {

  doctors:any;
  constructor(public dataService:DataService, private router:Router) { }

  ngOnInit() {
    let obsRes = this.dataService.getAllDoctors();
    obsRes.subscribe((result)=>{
      console.log(result);
      this.doctors=result;
    })
  }

}