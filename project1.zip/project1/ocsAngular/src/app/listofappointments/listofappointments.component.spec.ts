import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListofappointmentsComponent } from './listofappointments.component';

describe('ListofappointmentsComponent', () => {
  let component: ListofappointmentsComponent;
  let fixture: ComponentFixture<ListofappointmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListofappointmentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListofappointmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
