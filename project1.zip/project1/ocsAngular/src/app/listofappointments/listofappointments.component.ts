import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listofappointments',
  templateUrl: './listofappointments.component.html',
  styleUrls: ['./listofappointments.component.css']
})
export class ListofappointmentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
