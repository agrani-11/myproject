var express=require("express");
var router=express();
var mysql=require("mysql");
var Joi =require("joi");
var config=require("config");

var connection = mysql.createConnection({
    host:config.get("host"),
    database:config.get("database"),
    user:config.get("user"),
    password:config.get("password")
});
connection.connect();
router.use(express.json());

 router.post("/login",(request,response)=>{
   // var queryText="select users.userId,doctors.name,users.email from users inner join doctors on users.userId=doctors.u_id";
 //var queryText="select email,password,user_role from users;"

 var email=request.body.email;
 var password=request.body.password;
 var user_role=request.body.user_role;
 
    var queryText="'SELECT * FROM users WHERE email = ? AND password=? AND user_role=?";
    connection.query(queryText,[this.email],[this.password],[this.user_role],(err, result)=>{
    if(err==null)
      {
    // if(email==request.body.email && password==request.body.password && user_role==request.body.user_role)
      // { 
     //console.log("logged innn");
     response.send(JSON.stringify(result));
       }
      //else{
        //console.log("error");
     // }
    //}
   else
   {
    response.send(JSON.stringify(err));
   }
});
     
});
    


// router.get("/",(request,response)=>{
//     // var queryText="select users.userId,doctors.name,users.email from users inner join doctors on users.userId=doctors.u_id";
// var queryText="select userId,name,email,speciality from users inner join doctors on users.userId=doctors.u_id";
//     connection.query(queryText,(err,result)=>{
//         if(err==null)
//         {
//             response.send(JSON.stringify(result));
//         }
//         else
//         {
//             response.send(JSON.stringify(err));
//         }
//     });
// });

router.post("/insert",(request, response)=>{
    // var validationResult = Validate(request);

    // //console.log(validationResult.error);
    // if(validationResult.error==null)
    // {
     
          
            var userId = request.body.userId;
            var email=request.body.email;
            var name=request.body.name;
            var password=request.body.password;
            var user_role=request.body.user_role;

            var queryText = `insert into users values(${userId}, '${email}', '${name}', '${password}','${user_role}')`;
            connection.query(queryText,(err, result)=>{
            if(err==null)
                {
                    response.send(JSON.stringify(result));
                }
                else{
                    response.send(JSON.stringify(err));
                }
        });
    // }
    // else{
    //     response.send(JSON.stringify(validationResult.error));
    // }
    });

    // function Validate(request)
    // {
    //     var validationschema = 
    //     {
    //         userId:Joi.number().required(),
    //         email:Joi.string().email().required(),
    //         name:Joi.string().required(),
    //         password:Joi.string().regex(/^(?=.*[0-9])(?=.*[!#@$&*])[a-zA-Z0-9!#@$&*]{6,30}$/).required(),
    //         user_role:Joi.string().required()
    //     };
    //    return Joi.validate(request.body, validationschema)
    // }



    router.post("/insert",(request, response)=>{
       
         
              
                var userId = request.body.userId;
            
    
                var queryText = `insert into users values(${userId}, '${email}', '${name}', '${password}','${user_role}')`;
                connection.query(queryText,(err, result)=>{
                if(err==null)
                    {
                        response.send(JSON.stringify(result));
                    }
                    else{
                        response.send(JSON.stringify(err));
                    }
            });
     
        });

        router.put("/:userId",(request, response)=>{
            var userId = request.params.userId;
            var name = request.body.name;
            var email= request.body.email;
            var password=request.body.password;
        
            var queryText = `update users set name='${name}',email='${email}',password='${password}' where userId=${userId}`;
            connection.query(queryText,(err, result)=>{
                if(err==null)
                    {
                        response.send(JSON.stringify(result));
                    }
                    else{
                        response.send(JSON.stringify(err));
                    }
            });
        });
        

module.exports =router;
