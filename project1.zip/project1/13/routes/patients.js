var express=require("express");
var patientsRouter=express();
var mysql=require("mysql");
var Joi =require("joi");
var config=require("config");

var connection = mysql.createConnection({
    host:config.get("host"),
    database:config.get("database"),
    user:config.get("user"),
    password:config.get("password")
});
connection.connect();

patientsRouter.delete("/",(request, response)=>{
    var u_id = request.params.u_id;
    var queryText = `select * from  patients`;
    connection.query(queryText,(err, result)=>{
        if(err==null)
            {
                response.send(JSON.stringify(result));
            }
            else{
                response.send(JSON.stringify(err));
            }
    });
});


module.exports =patientsRouter;