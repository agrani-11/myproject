var express =  require("express");
var adminRouter = express();
var mysql=require("mysql");
var Joi =require("joi");
var config=require("config");


var connection = mysql.createConnection({
    host:config.get("host"),
    database:config.get("database"),
    user:config.get("user"),
    password:config.get("password")
});
connection.connect();



//to get users details
adminRouter.get("/userslist",(request,response)=>{
    var queryText="select * from users";

    connection.query(queryText,(err,result)=>{
        if(err==null)
        {
            response.send(JSON.stringify(result));
        }
        else
        {
            response.send(JSON.stringify(err));
        }
    });
});
 //admin can delete users
 adminRouter.delete("/:userId",(request, response)=>{
    var userId = request.params.userId;
    var queryText = `delete from  users where userId=${userId}`;
    connection.query(queryText,(err, result)=>{
        if(err==null)
            {
                response.send(JSON.stringify(result));
            }
            else{
                response.send(JSON.stringify(err));
            }
    });
});
//doclist disply

adminRouter.get("/doctorslist",(request,response)=>{

    // var drId=request.body.drId;
    // var contact=request.body.contact;
    // var dName=request.body.dName;
    // var daysInWeek=request.body.daysInWeek;
    // var experience =request.body.experience;
    // var fees=request.body.fees;
    // var speciality=request.body.speciality;
    var queryText=`select drId,contact,dName,daysInWeek,experience,fees,speciality from doctors`;

     
    connection.query(queryText,(err,result)=>{
        if(err==null)
        {
            response.send(JSON.stringify(result));
        }
        else
        {
            response.send(JSON.stringify(err));
        }
    });
});

 //admin can delete doctor
 adminRouter.delete("/:u_id",(request, response)=>{
    var u_id = request.params.u_id;
    var queryText = `delete from  doctors where u_id=${u_id}`;
    connection.query(queryText,(err, result)=>{
        if(err==null)
            {
                response.send(JSON.stringify(result));
            }
            else{
                response.send(JSON.stringify(err));
            }
    });
});

 adminRouter.get("/",(request,response)=>{
    var queryText="select * from admin";
    
    connection.query(queryText,(err,result)=>{
        if(err==null)
        {
            response.send(JSON.stringify(result));
        }
        else
        {
            response.send(JSON.stringify(err));
        }
    });
});

//admin by id
 adminRouter.get("/:id", (request, response)=>
 {
     //response.send("You searched for Admin No " + request.params.id);
     var queryText = `select * from admin where id = ${request.params.id}`;
     connection.query(queryText,(err, result)=>{
         if(err==null)
             {
                 response.send(JSON.stringify(result));
             }
             else{
                 response.send(JSON.stringify(err));
             }
     });
 });






module.exports =adminRouter;
