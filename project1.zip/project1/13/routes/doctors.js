var express=require("express");
var doctorsRouter=express();
var mysql=require("mysql");
var Joi =require("joi");
var config=require("config");

var connection = mysql.createConnection({
    host:config.get("host"),
    database:config.get("database"),
    user:config.get("user"),
    password:config.get("password")
});
connection.connect();


doctorsRouter.get("/doctorslist",(request,response)=>{

    // var drId=request.body.drId;
    // var contact=request.body.contact;
    // var dName=request.body.dName;
    // var daysInWeek=request.body.daysInWeek;
    // var experience =request.body.experience;
    // var fees=request.body.fees;
    // var speciality=request.body.speciality;
    var queryText=`select drId,contact,dName,daysInWeek,experience,fees,speciality from doctors;`;
    connection.query(queryText,(err,result)=>{
        if(err==null)
        {
            response.send(JSON.stringify(result));
        }
        else
        {
            response.send(JSON.stringify(err));
        }
    });
});


module.exports =doctorsRouter;