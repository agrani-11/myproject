var express =  require("express");
//var appointmentsRouter = require("./routes/appointments");
var usersRouter = require("./routes/users");
var doctorsRouter = require("./routes/doctors");
var patientsRouter = require("./routes/patients");
//var receptionistsRouter = require("./routes/receptionists");
var adminRouter = require("./routes/admin");
var config = require("config");

var port =   parseInt(config.get("port"));
var app =  express();

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

//app.use("/emps", empsRouter);
app.use("/admin", adminRouter);
app.use("/users", usersRouter);
app.use("/doctors", doctorsRouter);
//app.use("/receptionists", receptionstsRouter);
//app.use("/appointments", appointmentsRouter);
app.use("/patients",patientsRouter);

app.listen(port, ()=>{
    console.log(" 🌍 Server Started on 9000..");
});




